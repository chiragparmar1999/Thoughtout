import { createClient } from "@supabase/supabase-js";

// Server-only client (used inside app/api routes). Never import in client components.
export const supabaseAdmin = () =>
  createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false },
  });
